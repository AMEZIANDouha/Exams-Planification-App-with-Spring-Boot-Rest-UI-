package com.ensah.core.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Personne;

public interface IPersonneRepository extends JpaRepository<Personne, Long> {

	Personne getPersonneByCin(String cin);
	
    //Personne findByEnseignant_Id(Long idEnseignant);
	
	@Query("SELECT p.nom, p.prenom, p.cin, p.idPersonne, p.email FROM Personne p")
    List<Object[]> findAllPersonneInfo();
    
    
    
    
    
    
    
    
}
