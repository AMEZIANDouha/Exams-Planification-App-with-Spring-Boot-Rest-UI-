package com.ensah.core.services.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ensah.core.bo.CadreAdministrateur;
import com.ensah.core.bo.Personne;
import com.ensah.core.dao.CadreAdministrateurRepository;
import com.ensah.core.dao.IPersonneRepository;
import com.ensah.core.services.AdminService;
import com.ensah.core.services.exceptions.EntityNotFoundException;

import jakarta.transaction.Transactional;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private IPersonneRepository personneRepository;

    @Autowired
    private CadreAdministrateurRepository adminRepository;

    @Transactional
    public CadreAdministrateur createAdmin(CadreAdministrateur admin) {
        // Créer d'abord la personne
        Personne personne = new Personne();
        personne.setNom(admin.getNom());
        personne.setPrenom(admin.getPrenom());
        personne.setCin(admin.getCin());
        personne.setEmail(admin.getEmail());
        personne.setTelephone(admin.getTelephone());
        personne.setNomArabe(admin.getNomArabe());
        personne.setPrenomArabe(admin.getPrenomArabe());
        personne.setPhoto(admin.getPhoto());

        // Sauvegarder la personne
        personne = personneRepository.save(personne);

        if (personne == null) {
            throw new EntityNotFoundException("Failed to create admin. Personne not saved.");
        }

        // Associer l'ID de la personne à l'administrateur
        admin.setIdPersonne(personne.getIdPersonne());
        admin.setGrade(admin.getGrade());

        // Sauvegarder l'administrateur
        return adminRepository.save(admin);
    }

    @Transactional
    public void deleteAdmin(Long id) {
        personneRepository.deleteById(id);

        adminRepository.deleteById(id);
    }

    @Transactional
    public CadreAdministrateur updateAdmin(Long id, CadreAdministrateur adminDetails) {
        CadreAdministrateur admin = adminRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Admin not found with ID: " + id));

        Personne personne = personneRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Personne not found with ID: " + id));

        // Mettre à jour les informations de la personne
        personne.setNom(adminDetails.getNom());
        personne.setPrenom(adminDetails.getPrenom());
        personne.setCin(adminDetails.getCin());
        personne.setEmail(adminDetails.getEmail());
        personne.setTelephone(adminDetails.getTelephone());
        personne.setNomArabe(adminDetails.getNomArabe());
        personne.setPrenomArabe(adminDetails.getPrenomArabe());
        personne.setPhoto(adminDetails.getPhoto());

        // Sauvegarder la personne
        personneRepository.save(personne);

        // Mettre à jour les informations spécifiques à l'administrateur
        admin.setGrade(adminDetails.getGrade());

        // Sauvegarder l'administrateur
        return adminRepository.save(admin);
    }
}
