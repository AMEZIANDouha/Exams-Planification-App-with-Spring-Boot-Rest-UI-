package com.ensah.core.bo;
import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Semestre {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idSemestre;

    private String intitule;

    // Relation one-to-many avec les examens
    @OneToMany(mappedBy = "semestre")
    private List<Examen> examens;

    // Getters and setters

    public Long getId() {
        return idSemestre;
    }

    public void setId(Long idSemestre) {
        this.idSemestre = idSemestre;
    }

    public String getIntitule() {
        return intitule;
    }

    public void setIntitule(String intitule) {
        this.intitule = intitule;
    }

    public List<Examen> getExamens() {
        return examens;
    }

    public void setExamens(List<Examen> examens) {
        this.examens = examens;
    }
}