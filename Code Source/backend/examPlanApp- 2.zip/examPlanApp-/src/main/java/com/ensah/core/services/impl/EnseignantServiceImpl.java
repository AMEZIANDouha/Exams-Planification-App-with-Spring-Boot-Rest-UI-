package com.ensah.core.services.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ensah.core.bo.Departement;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Personne;
import com.ensah.core.dao.IDepartementRepository;
import com.ensah.core.dao.IEnseignantRepository;
import com.ensah.core.dao.IPersonneRepository;
import com.ensah.core.services.EnseignantService;
import com.ensah.core.services.IPersonneService;
import com.ensah.core.services.exceptions.EntityNotFoundException;
import java.util.Optional;
import jakarta.transaction.Transactional;


@Service
public class EnseignantServiceImpl implements EnseignantService {
	
	@Autowired
    private IPersonneRepository personneRepository;

    @Autowired
    private IEnseignantRepository enseignantRepository;
    
    @Autowired
    private IDepartementRepository departementRepository;

    @Transactional
    public Enseignant createEnseignant(Enseignant enseignant) {
        // Créer d'abord la personne
        Personne personne = new Personne();
        personne.setNom(enseignant.getNom());
        personne.setPrenom(enseignant.getPrenom());
        personne.setCin(enseignant.getCin());
        personne.setEmail(enseignant.getEmail());
        personne.setTelephone(enseignant.getTelephone());
        personne.setNomArabe(enseignant.getNomArabe());
        personne.setPrenomArabe(enseignant.getPrenomArabe());
        personne.setPhoto(enseignant.getPhoto());
        // Sauvegarder la personne
        personne = personneRepository.save(personne);
        // Associer l'ID de la personne à l'enseignant
        enseignant.setIdPersonne(personne.getIdPersonne());
        enseignant.setSpecialite(enseignant.getSpecialite()); 
        enseignant.setDepartement(enseignant.getDepartement()); 
        // Sauvegarder l'enseignant
        return enseignantRepository.save(enseignant);
    }
    @Transactional
    public void deleteEnseignant(Long id) {
        enseignantRepository.deleteById(id);
        personneRepository.deleteById(id);
    }

    @Transactional
    public Enseignant updateEnseignant(Long id, Enseignant enseignantDetails) {
        Enseignant enseignant = enseignantRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Enseignant not found with ID: " + id));

        Personne personne = personneRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Personne not found with ID: " + id));

        // Update Personne details
        personne.setNom(enseignantDetails.getNom());
        personne.setPrenom(enseignantDetails.getPrenom());
        personne.setCin(enseignantDetails.getCin());
        personne.setEmail(enseignantDetails.getEmail());
        personne.setTelephone(enseignantDetails.getTelephone());
        // Save Personne
        personneRepository.save(personne);
        
        // Update Enseignant details
        enseignant.setSpecialite(enseignantDetails.getSpecialite());
        
        Departement departement = enseignantDetails.getDepartement();
        if (departement != null && departement.getNom() != null) {
            // Check if the Departement exists in the database
            Optional<Departement> existingDepartementOptional = departementRepository.findByNom(departement.getNom());
            if (existingDepartementOptional.isPresent()) {
                Departement existingDepartement = existingDepartementOptional.get();
                // Update Enseignant's Departement with the existing Departement
                enseignant.setDepartement(existingDepartement);
            } else {
                // Handle the scenario when the Departement is not found
                throw new EntityNotFoundException("Departement not found with Name: " + departement.getNom());
            }
        } else {
            // Handle the scenario when the Departement is not specified
            throw new EntityNotFoundException("Departement not specified");
        }

        enseignant.setFiliere(enseignantDetails.getFiliere());
        // Save Enseignant
        return enseignantRepository.save(enseignant);
    }
    
    @Transactional
    public Enseignant getById(Long id) {
        return enseignantRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Enseignant not found with ID: " + id));
    }
}
