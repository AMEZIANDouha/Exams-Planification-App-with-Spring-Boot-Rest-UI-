package com.ensah.core.services;

import java.util.List;

import com.ensah.core.bo.ElementPedagogique;

public interface ElementPedagogiqueService {
    
    ElementPedagogique updateElementPedagogique(Long id, ElementPedagogique elementPédagogique);

    void deleteElementPedagogique(Long id);

    ElementPedagogique getElementPedagogiqueById(Long id);

    List<ElementPedagogique> getAllElementPedagogiques();

	ElementPedagogique createElementPedagogique(ElementPedagogique elementPedagogique, Long idEnseignant);
}