package com.ensah.core.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Niveau {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idNiveau;

    private String nom;

    @OneToMany(mappedBy = "niveau")
    @JsonIgnore
    private List<ElementPedagogique> elementsPedagogiques;

    // Getters and setters

    public Long getIdNiveau() {
        return idNiveau;
    }

    public void setIdNiveau(Long idNiveau) {
        this.idNiveau = idNiveau;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public List<ElementPedagogique> getElementsPedagogiques() {
        return elementsPedagogiques;
    }

    public void setElementsPedagogiques(List<ElementPedagogique> elementsPedagogiques) {
        this.elementsPedagogiques = elementsPedagogiques;
    }
}

