package com.ensah.core.bo;

import jakarta.persistence.Entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class ElementPedagogique {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titre;

    @ManyToOne
    private Niveau niveau;
    
    @OneToMany(mappedBy = "elementPedagogique")
    private List<Examen> examens;
    
    @ManyToOne
    private Enseignant enseignant;
    
    @ManyToOne
    @JsonIgnore
    private TypeElement typeElement;


    public List<Examen> getExamens() {
        return examens;
    }

    public void setExamens(List<Examen> examens) {
        this.examens = examens;
    }

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public Niveau getNiveau() {
        return niveau;
    }

    public void setNiveau(Niveau niveau) {
        this.niveau = niveau;
    }
    
    @ManyToOne
    private Enseignant coordonnateur;
    
    public void setTypeElement(TypeElement typeElement) {
        this.typeElement = typeElement;
    }
    

    public Enseignant getCoordonnateur() {
        return coordonnateur;
    }

    public void setCoordonnateur(Enseignant coordonnateur) {
        this.coordonnateur = coordonnateur;
    }

    public TypeElement getType() {
        return typeElement;
    }

	public void setEnseignant(Enseignant enseignant) {
        this.enseignant = enseignant;
		
	}
	
    public Enseignant getEnseignant() {
        return enseignant;
    }
	
}

    
