package com.ensah.core.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.ensah.core.bo.ElementPedagogique;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.dao.ElementPedagogiqueRepository;
import com.ensah.core.dao.IEnseignantRepository;
import com.ensah.core.dao.IExamenRepository;
import com.ensah.core.services.ElementPedagogiqueService;
import com.ensah.core.services.exceptions.EntityNotFoundException;

import jakarta.transaction.Transactional;

@Service
public class ElementPedagogiqueServiceImpl implements ElementPedagogiqueService {

    @Autowired
    private ElementPedagogiqueRepository elementPedagogiqueRepository;
    @Autowired
    private IEnseignantRepository enseignantRepository;
    @Autowired
    private IExamenRepository examenRepository;



    @Override
    public ElementPedagogique createElementPedagogique(ElementPedagogique elementPedagogique, Long idEnseignant) {
        ElementPedagogique savedElement = elementPedagogiqueRepository.save(elementPedagogique);
        Enseignant enseignant = enseignantRepository.findById(idEnseignant).orElseThrow(() -> new RuntimeException("Enseignant not found"));
        enseignant.getElementsPedagogiques().add(savedElement);
        enseignantRepository.save(enseignant);
        return savedElement;
    }

    
    @Override
    public ElementPedagogique updateElementPedagogique(Long id, ElementPedagogique elementPedagogique) {
    	    ElementPedagogique existingElementPédagogique = elementPedagogiqueRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Élément pédagogique non trouvé avec l'ID : " + id));
       
            existingElementPédagogique.setTitre(elementPedagogique.getTitre());
            existingElementPédagogique.setNiveau(elementPedagogique.getNiveau());
            existingElementPédagogique.setCoordonnateur(elementPedagogique.getCoordonnateur());
            existingElementPédagogique.setTypeElement(elementPedagogique.getType());
            return elementPedagogiqueRepository.save(existingElementPédagogique);
        
       
    }

    @Transactional
    public void deleteElementPedagogique(Long id) {
        try {
            // Step 1: Delete associations from Enseignant_elementsPedagogiques table
            List<Enseignant> enseignants = enseignantRepository.findAll();
            for (Enseignant enseignant : enseignants) {
                List<ElementPedagogique> elementsPedagogiques = enseignant.getElementsPedagogiques();
                for (ElementPedagogique elementPedagogique : elementsPedagogiques) {
                    if (elementPedagogique.getId().equals(id)) {
                        // Remove association from the list
                        elementsPedagogiques.remove(elementPedagogique);
                        // Update the Enseignant entity
                        enseignant.setElementsPedagogiques(elementsPedagogiques);
                        enseignantRepository.save(enseignant);
                        break; // Stop iterating once the association is removed
                    }
                }
            }
            // Step 2: Delete the ElementPedagogique entity
            examenRepository.deleteByElementPedagogiqueId(id);
            elementPedagogiqueRepository.deleteById(id);
        } catch (EmptyResultDataAccessException e) {
            throw new EntityNotFoundException("Élément pédagogique non trouvé avec l'ID : " + id);
        }
    }
    
    @Override
    public List<ElementPedagogique> getAllElementPedagogiques() {
        return elementPedagogiqueRepository.findAll();
    }


    @Override
    public ElementPedagogique getElementPedagogiqueById(Long id) {
        ElementPedagogique elementPedagogique = elementPedagogiqueRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Element pedagogique not found with id: " + id));

        // Create a simplified object with only the required fields
        ElementPedagogique simplifiedElementPedagogique = new ElementPedagogique();
        simplifiedElementPedagogique.setId(elementPedagogique.getId());
        simplifiedElementPedagogique.setTitre(elementPedagogique.getTitre());
        simplifiedElementPedagogique.setNiveau(elementPedagogique.getNiveau());

        return simplifiedElementPedagogique;
    }

    //@Override
    //public ElementPedagogique getElementPedagogiqueById(Long id) {
        //return elementPedagogiqueRepository.findById(id)
                //.orElseThrow(() -> new EntityNotFoundException("Élément pédagogique non trouvé avec l'ID : " + id));
    //}
    


}
