package com.ensah.core.bo;
import java.util.HashSet;

import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;


@Entity
public class TypeExamen {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idType;

    private String intitule;
    
    @OneToMany(mappedBy = "typeExamen", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Examen> examens = new HashSet<>();;

    // Getters and setters
    
    
    public Set<Examen> getExamens() {
        return examens;
    }

    public void setExamens(Set<Examen> examens) {
        this.examens=examens;
    }

    
    
    public Long getId() {
        return idType;
    }

    public void setId(Long idType) {
        this.idType = idType;
    }

    public String getIntitule() {
        return intitule;
    }

    public void setIntitule(String intitule) {
        this.intitule = intitule;
    }
}