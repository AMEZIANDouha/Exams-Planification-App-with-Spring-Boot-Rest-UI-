package com.ensah.core.services;

import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.GroupeEnseignant;

import java.util.List;

public interface GroupeEnseignantService {
    GroupeEnseignant createGroupeEnseignant(GroupeEnseignant groupeEnseignant);
    GroupeEnseignant updateGroupeEnseignant(GroupeEnseignant groupeEnseignant);
    void deleteGroupeEnseignant(Long id);
    GroupeEnseignant getGroupeEnseignantById(Long id);
    List<GroupeEnseignant> getAllGroupesEnseignants();
    void createGroupesForSameFiliere();
    void createGroupesEnseignantsArbitraire(String nomGroupe, List<String> nomsEnseignants);
	void createGroupesEnseignantsByDepartement(String departmentName);
	List<Enseignant> getEnseignantsByGroupeEnseignantId(Long groupeEnseignantId);
}
