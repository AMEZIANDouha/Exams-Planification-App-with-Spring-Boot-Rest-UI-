package com.ensah.core.bo;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Surveillance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idSurveillance;

    @ManyToOne
    private Enseignant coordonnateur;

    @ManyToMany
    @JoinTable(
        name = "surveillance_enseignant",
        joinColumns = @JoinColumn(name = "surveillance_id"),
        inverseJoinColumns = @JoinColumn(name = "enseignant_id")
    )
    private List<Enseignant> surveillants;

    @ManyToOne
    @JoinColumn(name = "controleurAbsence_idCadreAdmin")
    private CadreAdministrateur controleurAbsence;

    @ManyToOne
    @JoinColumn(name = "examen_id", referencedColumnName = "id_examen", nullable = false)
    private Examen examen;

    @ManyToOne
    private Salle salle;

    // Getters et setters

    public Long getIdSurveillance() {
        return idSurveillance;
    }

    public void setIdSurveillance(Long idSurveillance) {
        this.idSurveillance = idSurveillance;
    }

    public Enseignant getCoordonnateur() {
        return coordonnateur;
    }

    public void setCoordonnateur(Enseignant coordonnateur) {
        this.coordonnateur = coordonnateur;
    }

    public List<Enseignant> getSurveillants() {
        return surveillants;
    }

    public void setSurveillants(List<Enseignant> surveillants) {
        this.surveillants = surveillants;
    }


    public CadreAdministrateur getControleurAbsence() {
        return controleurAbsence;
    }

    public void setControleurAbsence(CadreAdministrateur controleurAbsence) {
        this.controleurAbsence = controleurAbsence;
    }


    public Examen getExamen() {
        return examen;
    }

    public void setExamen(Examen examen) {
        this.examen = examen;
    }

    public Salle getSalle() {
        return salle;
    }

    public void setSalle(Salle salle) {
        this.salle = salle;
    }
}
