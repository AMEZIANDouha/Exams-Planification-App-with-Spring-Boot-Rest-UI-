package com.ensah.core.dao;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.ensah.core.bo.Session;

@Repository
public interface SessionRepository extends JpaRepository<Session, Long> {
}
