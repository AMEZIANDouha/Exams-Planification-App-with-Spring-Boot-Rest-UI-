package com.ensah.core.dao;

import com.ensah.core.bo.Surveillance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SurveillanceRepository extends JpaRepository<Surveillance, Long> {


}
