package com.ensah.core.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Time;
import java.util.Date;
import java.util.List;

import com.ensah.core.bo.ElementPedagogique;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Examen;
import com.ensah.core.bo.Salle;
import com.ensah.core.bo.Semestre;
import com.ensah.core.bo.Session;
import com.ensah.core.bo.TypeExamen;

@Repository
public interface IExamenRepository extends JpaRepository<Examen, Long> {

    void deleteByElementPedagogiqueId(Long id);
    
    @Query("SELECT e FROM Examen e WHERE YEAR(e.date) = YEAR(CURRENT_DATE) - 1")
    List<Examen> getExamsFromPreviousYear();
    
    @Query("SELECT e FROM Examen e JOIN FETCH e.salles JOIN FETCH e.coordinateur JOIN FETCH e.elementPedagogique JOIN FETCH e.typeExamen JOIN FETCH e.session JOIN FETCH e.semestre WHERE e.date = :date AND e.heureDebut = :heureDebut AND e.coordinateur = :coordinateur AND e.elementPedagogique = :elementPedagogique AND e.typeExamen = :typeExamen AND e.session = :session AND e.semestre = :semestre")
    List<Examen> findByAttributs(@Param("date") Date date, @Param("heureDebut") Time heureDebut, @Param("coordinateur") Enseignant coordinateur, @Param("elementPedagogique") ElementPedagogique elementPedagogique, @Param("typeExamen") TypeExamen typeExamen, @Param("session") Session session, @Param("semestre") Semestre semestre);

    @Query("SELECT e FROM Examen e JOIN e.salles s WHERE e.date = :date AND s.idSalle IN :salleIds")
    List<Examen> findByDateAndSalles(@Param("date") Date date, @Param("salleIds") List<Long> salleIds);
}
