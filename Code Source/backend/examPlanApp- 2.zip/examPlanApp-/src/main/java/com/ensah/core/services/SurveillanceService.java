package com.ensah.core.services;

import java.util.List;

import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Surveillance;

public interface SurveillanceService {
        
    void assignSurveillantsAndAbsenceControllers(Long examenId);

	void assignRandomSurveillants(Long examenId, Long groupeEnseignantId, int nombreSurveillants);

	List<Enseignant> assignRandomSurveillantsFromEnseignants(Long examenId, int nombreSurveillants);
}
