package com.ensah.core.web.controllers;

import com.ensah.core.bo.ElementPedagogique;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Niveau;
import com.ensah.core.bo.TypeElement;
import com.ensah.core.services.ElementPedagogiqueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/element-pedagogique")
public class ElementPedagogiqueController {

    @Autowired
    private ElementPedagogiqueService elementPedagogiqueService;

    @GetMapping("/add")
    public ElementPedagogique createElementPedagogique(
            @RequestParam("Titre") String titre,
            @RequestParam("IdCoordonnateur") Long idCoordonnateur,
            @RequestParam("IdEnseignant") Long idEnseignant,
            @RequestParam("IdNiveau") Long idNiveau,
            @RequestParam("IdTypeElement") Long idTypeElement) {
        
        Niveau niveau = new Niveau();
        niveau.setIdNiveau(idNiveau);
        
        Enseignant enseignant  = new Enseignant();
        enseignant.setIdPersonne(idEnseignant);
        Enseignant coordonnateur  = new Enseignant();
        coordonnateur.setIdPersonne(idCoordonnateur);
        
        TypeElement type = new TypeElement();
        type.setIdType(idTypeElement);
        
        ElementPedagogique elementPedagogique = new ElementPedagogique();
        elementPedagogique.setTitre(titre);
        elementPedagogique.setEnseignant(enseignant);
        elementPedagogique.setCoordonnateur(coordonnateur);
        elementPedagogique.setNiveau(niveau);
        elementPedagogique.setTypeElement(type);

        return elementPedagogiqueService.createElementPedagogique(elementPedagogique, idEnseignant);
    }

    @RequestMapping(value = "/Update/{id}")
    @ResponseBody
    public ElementPedagogique updateElementPedagogique(
            @RequestParam("ID") Long id,
            @RequestParam("Titre") String titre,
            @RequestParam("IdNiveau") Long idNiveau,
            @RequestParam("NomNiveau") String NomNiveau
            ) {
        
        Niveau niveau = new Niveau();
        niveau.setIdNiveau(idNiveau);
        niveau.setNom(NomNiveau);

        
        ElementPedagogique elementPedagogique = new ElementPedagogique();
        elementPedagogique.setTitre(titre);
        elementPedagogique.setNiveau(niveau);
        return elementPedagogiqueService.updateElementPedagogique(id, elementPedagogique);
    }

    @RequestMapping(value = "/Delete/{id}")
    @ResponseBody
    public void deleteElementPedagogique(@PathVariable Long id) {
        elementPedagogiqueService.deleteElementPedagogique(id);
    }
    @RequestMapping(value = "/{id}")
    @ResponseBody
    public ElementPedagogique getElementPedagogiqueById(@PathVariable Long id) {
        return elementPedagogiqueService.getElementPedagogiqueById(id);
    }
    
    @RequestMapping(value = "/all")
    @ResponseBody
    public ResponseEntity<List<ElementPedagogique>> getAllElementPedagogiques() {
        List<ElementPedagogique> elementPedagogiques = elementPedagogiqueService.getAllElementPedagogiques();
        return new ResponseEntity<>(elementPedagogiques, HttpStatus.OK);
    }


}