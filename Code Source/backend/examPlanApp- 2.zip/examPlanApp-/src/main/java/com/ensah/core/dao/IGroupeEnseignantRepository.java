package com.ensah.core.dao;

import com.ensah.core.bo.GroupeEnseignant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IGroupeEnseignantRepository extends JpaRepository<GroupeEnseignant, Long> {
}
