package com.ensah.core.bo;

import java.sql.Date;


import java.sql.Time;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import java.util.List;


import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Examen {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_examen;

    
    private Date date ;
    
    
    private Time heureDebut;
    
    private int dureePrevue;

    private int dureeReelle;
    
    
    @OneToMany(mappedBy = "examen")
    private List<Salle> salles;

    
    @ManyToOne
    private Enseignant coordinateur;

    
    @ManyToMany
    private List<Enseignant> surveillants;

    @ManyToOne
    @JoinColumn(name = "controleurAbsence_idCadreAdmin")
    private CadreAdministrateur controleurAbsence;
    
    @OneToMany(mappedBy = "examen")
    private List<Surveillance> surveillances;
    
    
    // Relation many-to-one avec la session
    @ManyToOne
    private Session session;
    
    @ManyToOne
    private Semestre semestre; // Relation many-to-one avec le semestre
    
    @ManyToOne
    private TypeExamen typeExamen; // Relation many-to-one avec le type d'examen

    @ManyToOne
    private ElementPedagogique elementPedagogique;
    
    
    @Lob
    private byte[] epreuvePDF;

    @Lob
    private byte[] pvPDF;
    
    public byte[] getEpreuvePDF() {
        return epreuvePDF;
    }

    public void setEpreuvePDF(byte[] epreuvePDF) {
        this.epreuvePDF = epreuvePDF;
    }

    public byte[] getPvPDF() {
        return pvPDF;
    }

    public void setPvPDF(byte[] pvPDF) {
        this.pvPDF = pvPDF;
    }

    @Column(nullable = true)
    private String rapportTextuel;


    public String getRapportTextuel() {
        return rapportTextuel;
    }

    public void setRapportTextuel(String rapportTextuel) {
        this.rapportTextuel = rapportTextuel;
    }
    
    
 // Getter and setter for elementPedagogique
    public ElementPedagogique getElementPedagogique() {
        return elementPedagogique;
    }

    public void setElementPedagogique(ElementPedagogique elementPedagogique) {
        this.elementPedagogique = elementPedagogique;
        TypeElement typeElement = elementPedagogique.getType();
        
        if (typeElement != null && "module".equals(typeElement.getTitre())) {
            this.dureePrevue = 120; // 2 heures
        } else {
            this.dureePrevue = 90; // 1 heure 30 minutes
        }
    }

    public Long getId() {
        return id_examen;
    }

    public void setId(Long id_examen) {
        this.id_examen = id_examen;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Time getHeureDebut() {
        return heureDebut;
    }

    public void setHeureDebut(Time heureDebut) {
        this.heureDebut = heureDebut;
    }

    public int getDureePrevue() {
        return dureePrevue;
    }

    public void setDureePrevue(int dureePrevue) {
        this.dureePrevue = dureePrevue;
    }

    public int getDureeReelle() {
        return dureeReelle;
    }

    public void setDureeReelle(int dureeReelle) {
        this.dureeReelle = dureeReelle;
    }

    public Enseignant getCoordinateur() {
        return coordinateur;
    }

    public void setCoordinateur(Enseignant coordinateur) {
        this.coordinateur = coordinateur;
    }

    public List<Enseignant> getSurveillants() {
        return surveillants;
    }

    public void setSurveillants(List<Enseignant> surveillants) {
        this.surveillants = surveillants;
    }

    public CadreAdministrateur getControleursAbsence() {
        return controleurAbsence;
    }

    public void setControleursAbsence(CadreAdministrateur controleurAbsence) {
        this.controleurAbsence = controleurAbsence;
    }

    public List<Salle> getSalles() {
        return salles;
    }

    public void setSalles(List<Salle> salles) {
        this.salles = salles;
    }

	public void setSemestre(Semestre semestre) {
		
	}

	public void setSession(Session session) {
		
	}

	public void setTypeExamen(TypeExamen tp) {
		
	}

	public TypeExamen getTypeExamen() {
        return typeExamen;
    }


    
    public Session getSession() {
        return session;
    }

    public Semestre getSemestre() {
        return semestre;
    }



}
