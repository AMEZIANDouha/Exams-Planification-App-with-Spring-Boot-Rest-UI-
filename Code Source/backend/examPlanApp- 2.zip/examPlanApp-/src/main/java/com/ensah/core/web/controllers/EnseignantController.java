package com.ensah.core.web.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ensah.core.bo.Departement;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Filiere;
import com.ensah.core.services.EnseignantService;
import com.ensah.core.services.exceptions.EntityNotFoundException;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/enseignants")
@CrossOrigin(origins = "http://localhost:3000") // Allow requests from your frontend domain
public class EnseignantController {

    @Autowired
    private EnseignantService enseignantService;

    @GetMapping("/add")
    @ResponseBody
    public Enseignant createEnseignant(@RequestParam String prenom,
    	    @RequestParam String nom,
    	    @RequestParam String cin,
    	    @RequestParam String email,
    	    @RequestParam String telephone,
    	    @RequestParam String nomArabe,
    	    @RequestParam String prenomArabe,
    	    @RequestParam byte[] photo,
    	    @RequestParam String specialite,
    	    @RequestParam Long idDepartement,
    	    @RequestParam String NomD,
    	    @RequestParam Long idFiliere,
    	    @RequestParam String NomFiliere) {
        // Create an Enseignant object with the received parameters
        Enseignant enseignant = new Enseignant();
        enseignant.setPrenom(prenom);
        enseignant.setNom(nom);
        enseignant.setCin(cin);
        enseignant.setEmail(email);
        enseignant.setTelephone(telephone);
        enseignant.setNomArabe(nomArabe);
        enseignant.setPrenomArabe(prenomArabe);
        enseignant.setPhoto(photo);
        enseignant.setSpecialite(specialite);
        
        // Assuming you have a method to set the departement attribute
        Departement departement = new Departement();
        departement.setIdDepartement(idDepartement);
        departement.setNom(NomD);
        enseignant.setDepartement(departement);
        
        
        // Set the Filiere
        Filiere filiere = new Filiere();
        filiere.setIdFiliere(idFiliere);
        filiere.setNom(NomFiliere);
        enseignant.setFiliere(filiere);

        System.out.println("we're in");
        return enseignantService.createEnseignant(enseignant);
    }

    @RequestMapping(value = "/Delete/{id}")
    @ResponseBody
    public void deleteEnseignant(@PathVariable Long id) {
        enseignantService.deleteEnseignant(id);
    }

    @RequestMapping(value = "/Put/{id}")
    @ResponseBody
    public Enseignant updateEnseignant(@PathVariable Long id,
            @RequestParam String prenom,
            @RequestParam String nom,
            @RequestParam String cin,
            @RequestParam String email,
            @RequestParam String telephone,
            @RequestParam String specialite,
            @RequestParam String departement) {

    	// Create an Enseignant object with the received parameters
    	Enseignant enseignantDetails = new Enseignant();
    	enseignantDetails.setPrenom(prenom);
    	enseignantDetails.setNom(nom);
    	enseignantDetails.setCin(cin);
    	enseignantDetails.setEmail(email);
    	enseignantDetails.setTelephone(telephone);
    	enseignantDetails.setSpecialite(specialite);

    	// Set the Departement
    	Departement dp = new Departement();

    	dp.setNom(departement);
    	enseignantDetails.setDepartement(dp);

    	// Update and return the enseignant
    	return enseignantService.updateEnseignant(id, enseignantDetails);
    }

    
    // Endpoint to get an enseignant by ID
    @GetMapping("/Get/{id}")
    public Enseignant getEnseignantById(@PathVariable Long id) {
        Enseignant enseignant = enseignantService.getById(id);
        System.out.println("we're in");
        if (enseignant == null) {
            throw new EntityNotFoundException("Enseignant not found with ID: " + id);
        }
        return enseignant;
    }
}

