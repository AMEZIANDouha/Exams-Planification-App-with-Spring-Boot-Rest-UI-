package com.ensah.core.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Filiere;




public interface IEnseignantRepository extends JpaRepository<Enseignant, Long> {

    List<Enseignant> findByNom(String nom);
	List<Enseignant> findByFiliere(Filiere filiere);
	List<Enseignant> findByGroupesEnseignantId(Long groupeEnseignantId);
}


