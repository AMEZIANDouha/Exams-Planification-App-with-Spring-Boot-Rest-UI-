package com.ensah.core.bo;

import jakarta.persistence.*;
import java.util.List;

@Entity
@PrimaryKeyJoinColumn(name = "idCadreAdmin")
public class CadreAdministrateur extends Personne {

    private String grade;

    @OneToMany(mappedBy = "controleurAbsence", cascade = CascadeType.ALL)
    private List<Surveillance> surveillances;

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public List<Surveillance> getSurveillances() {
        return surveillances;
    }

    public void setSurveillances(List<Surveillance> surveillances) {
        this.surveillances = surveillances;
    }
}
