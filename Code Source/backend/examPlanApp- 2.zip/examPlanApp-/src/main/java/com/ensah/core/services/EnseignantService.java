package com.ensah.core.services;

import com.ensah.core.bo.Enseignant;

public interface EnseignantService {
	
	public Enseignant createEnseignant(Enseignant enseignant);
	
	public void deleteEnseignant(Long id);
	
	public Enseignant updateEnseignant(Long id, Enseignant enseignantDetails);
    public Enseignant getById(Long id); // Method to get an Enseignant by ID

	

}
