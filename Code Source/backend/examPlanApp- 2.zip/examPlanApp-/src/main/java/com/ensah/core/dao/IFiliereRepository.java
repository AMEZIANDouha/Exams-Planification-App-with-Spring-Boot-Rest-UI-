package com.ensah.core.dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ensah.core.bo.Filiere;



public interface IFiliereRepository extends JpaRepository<Filiere, Long> {
	List<Filiere> findAll();
	
}
