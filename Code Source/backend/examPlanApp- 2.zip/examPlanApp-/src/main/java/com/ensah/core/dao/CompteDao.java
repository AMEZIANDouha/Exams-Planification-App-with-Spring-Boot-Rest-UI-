package com.ensah.core.dao;

import com.ensah.core.bo.Compte;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompteDao extends JpaRepository<Compte, Long> {
    Optional<Compte> findCompteByLogin(String login);

	Compte getCompteByLogin(String username);
}

