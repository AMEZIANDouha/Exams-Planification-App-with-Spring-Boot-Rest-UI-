package com.ensah.core.services.impl;

import com.ensah.core.bo.CadreAdministrateur;
import com.ensah.core.bo.ElementPedagogique;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Examen;
import com.ensah.core.bo.GroupeEnseignant;
import com.ensah.core.bo.Surveillance;
import com.ensah.core.dao.CadreAdministrateurRepository;
import com.ensah.core.dao.IEnseignantRepository;
import com.ensah.core.dao.IExamenRepository;
import com.ensah.core.dao.IGroupeEnseignantRepository;
import com.ensah.core.dao.SurveillanceRepository;
import com.ensah.core.services.SurveillanceService;
import com.ensah.core.services.exceptions.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

@Service
public class SurveillanceServiceImpl implements SurveillanceService {

    @Autowired
    private SurveillanceRepository surveillanceRepository;

    @Autowired
    private IEnseignantRepository enseignantRepository;
    
    @Autowired
    private IExamenRepository examenRepository;
    
    @Autowired
    private CadreAdministrateurRepository cadreAdministrateurRepository;

    @Autowired
    private IGroupeEnseignantRepository groupeEnseignantRepository;

    @Override
    public void assignRandomSurveillants(Long examenId, Long groupeEnseignantId,int nombreSurveillants) {
    	// Récupérer l'examen et le groupe d'enseignants concernés
        GroupeEnseignant groupeEnseignant = groupeEnseignantRepository.findById(groupeEnseignantId)
                .orElseThrow(() -> new EntityNotFoundException("Groupe enseignant non trouvé avec l'ID : " + groupeEnseignantId));
        
        if (groupeEnseignant == null) {
           
        	throw new EntityNotFoundException("Group empty ! " );
        }
        List<Enseignant> enseignantsDuGroupe = groupeEnseignant.getEnseignants();

        // Sélectionner aléatoirement les enseignants du groupe
        List<Enseignant> surveillantsSelectionnes = new ArrayList<>();
        int tailleGroupe = enseignantsDuGroupe.size();
        if (tailleGroupe > nombreSurveillants) {
            Collections.shuffle(enseignantsDuGroupe, new Random()); // Mélanger la liste
            for (int i = 0; i < nombreSurveillants; i++) {
                surveillantsSelectionnes.add(enseignantsDuGroupe.get(i));}
        }else {
            surveillantsSelectionnes.addAll(enseignantsDuGroupe);
        }

        Examen examen = examenRepository.findById(examenId)
                .orElseThrow(() -> new EntityNotFoundException("Examen non trouvé avec l'ID : " + examenId));
        
        ElementPedagogique elementPedagogique = examen.getElementPedagogique();
        
        // Pour chaque surveillant sélectionné, créer une surveillance associée à l'examen
        for (Enseignant surveillant : surveillantsSelectionnes) {
            Surveillance surveillance = new Surveillance();
            surveillance.setExamen(examen); // Assigner l'examen
            List<Enseignant> surveillants = new ArrayList<>();
            surveillants.add(surveillant);
            surveillance.setSurveillants(surveillants); // Assigner les surveillants
            surveillanceRepository.save(surveillance);
        }
    }

    @Override
    public List<Enseignant> assignRandomSurveillantsFromEnseignants(Long examenId,int nombreSurveillants) {
    	
    	Examen examen = examenRepository.findById(examenId)
                .orElseThrow(() -> new EntityNotFoundException("Examen non trouvé avec l'ID : " + examenId));

        List<Enseignant> enseignants = enseignantRepository.findAll();

        // Sélectionner aléatoirement 2 enseignants
        List<Enseignant> surveillantsSelectionnes = new ArrayList<>();
        int tailleEnseignants = enseignants.size();
        if (tailleEnseignants > nombreSurveillants) {
            Collections.shuffle(enseignants, new Random()); // Mélanger la liste
            for (int i = 0; i < nombreSurveillants; i++) {
                surveillantsSelectionnes.add(enseignants.get(i));
            }
        } else {
            surveillantsSelectionnes.addAll(enseignants);
        }

        
        // Pour chaque surveillant sélectionné, créer une surveillance associée à l'examen
        for (Enseignant surveillant : surveillantsSelectionnes) {
            Surveillance surveillance = new Surveillance();
            surveillance.setExamen(examen); // Assigner l'examen
            List<Enseignant> surveillants = new ArrayList<>();
            surveillants.add(surveillant);
            surveillance.setSurveillants(surveillants); // Assigner les surveillants
            surveillanceRepository.save(surveillance);
        }

        return surveillantsSelectionnes;
    }

    @Override
    public void assignSurveillantsAndAbsenceControllers(Long examenId) {
    	Examen examen = examenRepository.findById(examenId)
                .orElseThrow(() -> new EntityNotFoundException("Examen non trouvé avec l'ID : " + examenId));
       

        // Récupérer tous les surveillants et contrôleurs d'absence
        List<Enseignant> allSurveillants = enseignantRepository.findAll();
        List<CadreAdministrateur> allAbsenceControllers = cadreAdministrateurRepository.findAll();

        // Filtrer les surveillants disponibles
        List<Enseignant> availableSurveillants = filterAvailableSurveillants(allSurveillants, examen);
        
        if (availableSurveillants.isEmpty()) {
            throw new RuntimeException("Aucun surveillant disponible pour l'examen avec l'ID : " + examenId);
        }
        List<CadreAdministrateur> availableAbsenceControllers = filterAvailableAbsenceControllers(allAbsenceControllers, examen);

        if (availableAbsenceControllers.isEmpty()) {
            throw new RuntimeException("Aucun contrôleur d'absence disponible pour l'examen avec l'ID : " + examenId);
        }
        // Assigner les surveillants et les contrôleurs d'absence
        assignSurveillantsToExamen(examen, availableSurveillants);
        assignAbsenceControllersToExamen(examen, availableAbsenceControllers);
    }

    private List<Enseignant> filterAvailableSurveillants(List<Enseignant> surveillants, Examen examen) {
        List<Enseignant> availableSurveillants = new ArrayList<>();
        for (Enseignant surveillant : surveillants) {
            if (isSurveillantAvailable(surveillant, examen)) {
                availableSurveillants.add(surveillant);
            }
        }
        return availableSurveillants;
    }

    private boolean isSurveillantAvailable(Enseignant surveillant, Examen examen) {
    	
    	int surveillancesCount = 0;

        for (Surveillance surveillance : surveillant.getSurveillances()) {
            Examen surveilledExamen = surveillance.getExamen();
            if (surveilledExamen.getDate().equals(examen.getDate())) {
            	
            	surveillancesCount++;
                
                if (surveillancesCount >= 4) {
                    System.out.println("Le surveillant " + surveillant.getNom() + " a déjà atteint le nombre maximal de surveillances pour la date " + examen.getDate());
                    return false; // Dépassement du seuil de surveillances
                }
            	
            	
                LocalTime surveillantStartTime = surveilledExamen.getHeureDebut().toLocalTime();
                LocalTime surveillantEndTime = surveillantStartTime.plusMinutes(surveilledExamen.getDureePrevue());
                LocalTime examStartTime = examen.getHeureDebut().toLocalTime();
                LocalTime examEndTime = examStartTime.plusMinutes(examen.getDureePrevue());

                if (!(examEndTime.isBefore(surveillantStartTime) || examStartTime.isAfter(surveillantEndTime))) {
                    return false; // Conflit d'horaire
                }
                
                
            }

            // Vérifier si l'enseignant est coordonnateur d'un autre examen à la même date et heure
            if (surveillance.getCoordonnateur().equals(surveillant) && surveilledExamen.getDate().equals(examen.getDate())) {
                LocalTime coordonnateurStartTime = surveilledExamen.getHeureDebut().toLocalTime();
                LocalTime coordonnateurEndTime = coordonnateurStartTime.plusMinutes(surveilledExamen.getDureePrevue());
                LocalTime examStartTime = examen.getHeureDebut().toLocalTime();
                LocalTime examEndTime = examStartTime.plusMinutes(examen.getDureePrevue());

                if (!(examEndTime.isBefore(coordonnateurStartTime) || examStartTime.isAfter(coordonnateurEndTime))) {
                    return false; // Conflit d'horaire en tant que coordonnateur
                }
            }
        }
        return true;
    }

    private List<CadreAdministrateur> filterAvailableAbsenceControllers(List<CadreAdministrateur> absenceControllers, Examen examen) {
        List<CadreAdministrateur> availableAbsenceControllers = new ArrayList<>();
        for (CadreAdministrateur controller : absenceControllers) {
            if (isAbsenceControllerAvailable(controller, examen)) {
                availableAbsenceControllers.add(controller);
            }
        }
        return availableAbsenceControllers;
    }

    private boolean isAbsenceControllerAvailable(CadreAdministrateur controller, Examen examen) {
        LocalTime examStartTime = examen.getHeureDebut().toLocalTime();
        LocalTime examEndTime = examStartTime.plusMinutes(15); // Durée fixe de 15 minutes
        
        int ControlesCount = 0;


        for (Surveillance surveillance : controller.getSurveillances()) {
            if (surveillance.getExamen().getDate().equals(examen.getDate())) {
            	
            	ControlesCount++;
                
                if (ControlesCount >= 4) {
                    System.out.println("Le controleur " + controller.getNom() + " a déjà atteint le nombre maximal de Controles pour la date " + examen.getDate());
                    return false; // Dépassement du seuil de surveillances
                }
            	
                LocalTime controllerStartTime = surveillance.getExamen().getHeureDebut().toLocalTime();
                LocalTime controllerEndTime = controllerStartTime.plusMinutes(15); // Période fixe de 15 minutes

                // Vérifie s'il y a un conflit d'horaire
                if (!(examEndTime.isBefore(controllerStartTime) || examStartTime.isAfter(controllerEndTime))) {
                    return false; // Conflit d'horaire
                }
            }
        }
        return true;
    }
    private void assignSurveillantsToExamen(Examen examen, List<Enseignant> availableSurveillants) {
        for (Enseignant surveillant : availableSurveillants) {
            Surveillance surveillance = new Surveillance();
            surveillance.setExamen(examen);
            List<Enseignant> surveillants = new ArrayList<>();
            surveillants.add(surveillant);
            surveillance.setSurveillants(surveillants);
            surveillanceRepository.save(surveillance);
        }
    }

    private void assignAbsenceControllersToExamen(Examen examen, List<CadreAdministrateur> availableAbsenceControllers) {
        for (CadreAdministrateur controller : availableAbsenceControllers) {
            Surveillance surveillance = new Surveillance();
            surveillance.setExamen(examen);
            surveillance.setControleurAbsence(controller);
            surveillanceRepository.save(surveillance);
        }
    }
}