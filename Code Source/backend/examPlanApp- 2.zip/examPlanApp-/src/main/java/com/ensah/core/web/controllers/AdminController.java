package com.ensah.core.web.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ensah.core.bo.CadreAdministrateur;
import com.ensah.core.bo.Departement;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Filiere;
import com.ensah.core.services.AdminService;
import com.ensah.core.services.EnseignantService;

@RestController
@RequestMapping("/api/admins")
public class AdminController {

    @Autowired
    private AdminService adminService;


    @RequestMapping("/createCadre")
    @ResponseBody
    public CadreAdministrateur createCadre(
        @RequestParam String nom,
        @RequestParam String cin,
        @RequestParam String email,
        @RequestParam String telephone,
        @RequestParam String nomArabe,
        @RequestParam String prenomArabe,
        @RequestParam byte[] photo,
        @RequestParam String Grade
      ) {
        
        // Create a CadreAdministrateur object with the received parameters
        CadreAdministrateur admin = new CadreAdministrateur();
        admin.setNom(nom);
        admin.setCin(cin);
        admin.setEmail(email);
        admin.setTelephone(telephone);
        admin.setNomArabe(nomArabe);
        admin.setPrenomArabe(prenomArabe);
        admin.setPhoto(photo);
        admin.setGrade(Grade);

        // Call your service method to create the CadreAdministrateur
        return adminService.createAdmin(admin);
    }

    @RequestMapping("/Delete/{id}")
    @ResponseBody
    public void deleteAdmin(@PathVariable Long id) {
    	adminService.deleteAdmin(id);
    }

    @RequestMapping("/Update")
    @ResponseBody
    public CadreAdministrateur updateAdmin(
            @RequestParam Long ID,
            @RequestParam String nom,
            @RequestParam String prenom,
            @RequestParam String cin,
            @RequestParam String email,
            @RequestParam String telephone,
            @RequestParam String Grade
          ) {
        // Create a CadreAdministrateur object with the received parameters
        CadreAdministrateur adminDetails = new CadreAdministrateur();
        adminDetails.setNom(nom);
        adminDetails.setPrenom(prenom);
        adminDetails.setCin(cin);
        adminDetails.setEmail(email);
        adminDetails.setTelephone(telephone);
        adminDetails.setGrade(Grade);
        return adminService.updateAdmin(ID, adminDetails);
    }
    
}
