package com.ensah.core.services.impl;

import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.ensah.core.bo.Personne;

@Repository
public class UserDao {

	public Optional<Personne> findUserByCin(Object cin) {
		// TODO Auto-generated method stub
		return null;
	}

	public void save(Personne user1) {
		// TODO Auto-generated method stub
		
	}

}
