package com.ensah.core.services.impl;

import java.util.ArrayList;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.sql.Date;
import java.sql.Time;

import com.ensah.core.bo.Examen;
import com.ensah.core.bo.Salle;
import com.ensah.core.dao.IExamenRepository;
import com.ensah.core.services.ExamenService;
import com.ensah.core.services.exceptions.EntityNotFoundException;
import com.ensah.core.services.exceptions.SchedulingConflictException;

import jakarta.transaction.Transactional;

@Service
public class ExamenServiceImpl implements ExamenService {
	
    @Override
    public List<Examen> getAllExams() {
        return examenRepository.findAll(); // Assuming you're using Spring Data JPA
    }
	
    @Autowired
    private IExamenRepository examenRepository;

    @Override
    public Examen createExamen(Examen examen) {
        // Vérifier si un examen identique existe déjà dans la base de données
        List<Examen> examensIdentiques = examenRepository.findByAttributs(
                examen.getDate(), examen.getHeureDebut(), examen.getCoordinateur(),
                examen.getElementPedagogique(), examen.getTypeExamen(), examen.getSession(), examen.getSemestre());

        if (!examensIdentiques.isEmpty()) {
            throw new RuntimeException("Un examen avec les mêmes détails existe déjà.");
        }
        // Extraire les IDs des salles
        List<Long> salleIds = examen.getSalles().stream().map(Salle::getIdSalle).collect(Collectors.toList());

        // Récupérer tous les examens existants à la même date et dans les mêmes salles
        List<Examen> examensExistants = examenRepository.findByDateAndSalles(examen.getDate(), salleIds);

        // Vérifier s'il y a des conflits d'horaires avec les examens existants
        LocalTime heureDebutNouvelExamen = examen.getHeureDebut().toLocalTime();
        LocalTime heureFinNouvelExamen = heureDebutNouvelExamen.plusMinutes(examen.getDureePrevue());

        for (Examen examenExist : examensExistants) {
            LocalTime heureDebutExist = examenExist.getHeureDebut().toLocalTime();
            LocalTime heureFinExist = heureDebutExist.plusMinutes(examenExist.getDureePrevue());

            if (heureDebutNouvelExamen.equals(heureDebutExist) || 
                (heureDebutNouvelExamen.isBefore(heureFinExist) && heureFinNouvelExamen.isAfter(heureDebutExist))) {
                throw new RuntimeException("Salle réservée à cette heure, veuillez choisir une autre option!");
            }
        }
        // Log pour le débogage
        System.out.println("IDs des salles : " + salleIds);
        System.out.println("Examens existants trouvés : " + examensExistants);

        // Aucun conflit d'horaire, enregistrer l'examen
        return examenRepository.save(examen);
    }

   /** public Examen updateExamen(Long id, Examen examen) {
        // Recherchez l'examen par ID
        Examen examenToUpdate = examenRepository.findById(id).orElse(null);
        if (examenToUpdate != null) {
            // Vérifier les conflits d'horaires avant de mettre à jour
            List<Examen> examensExistants = examenRepository.findByDateAndSalles(examen.getDate(), examen.getSalles());

            for (Examen examenExist : examensExistants) {
                if (!examenExist.getId().equals(id)) {
                    // Vérifier si l'heure de début de l'examen existant est la même que celle de l'examen que l'utilisateur souhaite mettre à jour
                    if (examenExist.getHeureDebut().equals(examen.getHeureDebut())) {
                        // L'heure de début est réservée, afficher un message d'erreur
                        throw new RuntimeException("Salle réservée à cette heure, veuillez choisir une autre option!");
                    }

                    // Convertir la durée de l'examen existant en heures et minutes
                    LocalTime heureDebutExist = examenExist.getHeureDebut().toLocalTime();
                    LocalTime heureFinExist = heureDebutExist.plusMinutes(examenExist.getDureePrevue());

                    LocalTime heureDebutNouvelExamen = examen.getHeureDebut().toLocalTime();

                    // Vérifier les conflits d'horaires
                    if (!heureDebutNouvelExamen.isAfter(heureFinExist) && !heureFinExist.isBefore(heureDebutNouvelExamen)) {
                        // Il y a un conflit d'horaires
                        throw new RuntimeException("Salle réservée à cette heure, veuillez choisir une autre option!");
                    }
                }
            }

            // Mettez à jour les attributs de l'examen avec les nouvelles valeurs
            examenToUpdate.setDate(examen.getDate());
            examenToUpdate.setHeureDebut(examen.getHeureDebut());
            examenToUpdate.setDureeReelle(examen.getDureePrevue());
            //  d'autres attributs...
            
            // Enregistrez les modifications dans la base de données
            return examenRepository.save(examenToUpdate);
        }else {
            // Si l'examen n'est pas trouvé, lancez une EntityNotFoundException
            throw new EntityNotFoundException("Examen not found with ID: " + id);
            }
        
    }
    */
    /** @Override
    public List<Examen> getExamsFromPreviousYear() {
        // Implémentation pour récupérer les examens de l'année précédente depuis la base de données
        List<Examen> examensAnneePrecedente = examenRepository.getExamsFromPreviousYear();
        
        // Implémentation pour créer de nouveaux examens pour l'année actuelle en se basant sur les examens de l'année précédente
        List<Examen> nouveauxExamens = new ArrayList<>();
        
        for (Examen examen : examensAnneePrecedente) {
            Examen nouveauExamen = new Examen();
            // Copiez les attributs nécessaires de l'examen de l'année précédente vers le nouveau examen
            nouveauExamen.setDate(examen.getDate());
            nouveauExamen.setHeureDebut(examen.getHeureDebut());
            nouveauExamen.setDureeReelle(examen.getDureePrevue());
            // autres attributs...

            // Vérifier les conflits d'horaires avant de sauvegarder le nouveau examen
            List<Examen> examensExistants = examenRepository.findByDateAndSalles(nouveauExamen.getDate(), nouveauExamen.getSalles());

            for (Examen examenExist : examensExistants) {
                // Vérifier si l'heure de début de l'examen existant est la même que celle du nouveau examen
                if (examenExist.getHeureDebut().equals(nouveauExamen.getHeureDebut())) {
                    // L'heure de début est réservée, afficher un message d'erreur
                    throw new RuntimeException("Salle réservée à cette heure, veuillez choisir une autre option!");
                }

                // Convertir la durée de l'examen existant en heures et minutes
                LocalTime heureDebutExist = examenExist.getHeureDebut().toLocalTime();
                LocalTime heureFinExist = heureDebutExist.plusMinutes(examenExist.getDureePrevue());

                LocalTime heureDebutNouvelExamen = nouveauExamen.getHeureDebut().toLocalTime();

                // Vérifier les conflits d'horaires
                if (!heureDebutNouvelExamen.isAfter(heureFinExist) && !heureFinExist.isBefore(heureDebutNouvelExamen)) {
                    // Il y a un conflit d'horaires
                    throw new RuntimeException("Salle réservée à cette heure, veuillez choisir une autre option!");
                }
            }

            // Ajouter le nouveau examen à la liste des nouveaux examens à sauvegarder
            nouveauxExamens.add(nouveauExamen);
        }
        
        // Sauvegardez les nouveaux examens dans la base de données
        return examenRepository.saveAll(nouveauxExamens);
    }*/
    @Override
    public Examen getExamenById(Long id) {
        return examenRepository.findById(id).orElse(null);
    }

	@Override
	public Examen updateExamen(Long id, Examen examen) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Examen> getExamsFromPreviousYear() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteExamen(Long id) {
		// TODO Auto-generated method stub
		
	}
    
}