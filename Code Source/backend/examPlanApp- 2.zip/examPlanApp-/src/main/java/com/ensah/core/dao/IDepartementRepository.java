package com.ensah.core.dao;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ensah.core.bo.Departement;
import com.ensah.core.bo.Enseignant;



public interface IDepartementRepository extends JpaRepository<Departement, Long> {
	
	List<Departement> findAll();

	Optional<Departement> findByNom(String nom);

}

