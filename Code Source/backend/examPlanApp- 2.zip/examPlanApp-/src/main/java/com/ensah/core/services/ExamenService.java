package com.ensah.core.services;

import java.util.List;

import com.ensah.core.bo.Examen;



public interface ExamenService {
    Examen createExamen(Examen examen);
    void deleteExamen(Long id);
    Examen updateExamen(Long id, Examen examen);
    Examen getExamenById(Long id);
    List<Examen> getExamsFromPreviousYear();
    List<Examen> getAllExams();
}
