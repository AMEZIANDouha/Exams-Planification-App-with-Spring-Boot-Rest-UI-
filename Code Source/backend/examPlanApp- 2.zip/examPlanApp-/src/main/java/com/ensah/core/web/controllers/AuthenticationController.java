package com.ensah.core.web.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.ensah.core.bo.*;
import com.ensah.core.services.impl.AuthenticationService;


@RestController
@CrossOrigin
public class AuthenticationController {
    @Autowired
    private AuthenticationService authenticationService;
    @RequestMapping(value ="/register")
    public ResponseEntity<?> register(@RequestBody UserPrincipal userPrincipal) {
    	System.out.println(userPrincipal.getUser());
        if (userPrincipal.getCompte() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Compte is required");
        }
        return ResponseEntity.ok(authenticationService.registre(userPrincipal));
    }

    @GetMapping(value = "/login")
    public ResponseEntity<?> login(@RequestParam String login, @RequestParam String password) {
        Compte compte = new Compte();
        compte.setLogin(login);
        compte.setPassword(password);
        UserPrincipal userPrincipal = new UserPrincipal(compte);
        return ResponseEntity.ok(authenticationService.login(userPrincipal));
    }
}

