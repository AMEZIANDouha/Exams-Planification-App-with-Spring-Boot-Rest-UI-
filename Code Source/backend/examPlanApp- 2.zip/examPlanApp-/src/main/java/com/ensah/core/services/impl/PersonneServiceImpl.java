package com.ensah.core.services.impl;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import javax.imageio.ImageIO;

import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ensah.core.bo.CadreAdministrateur;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Personne;
import com.ensah.core.dao.CadreAdministrateurRepository;
import com.ensah.core.dao.IEnseignantRepository;
import com.ensah.core.dao.IPersonneRepository;
import com.ensah.core.services.IPersonneService;
import com.ensah.core.services.exceptions.EntityNotFoundException;
import com.ensah.core.utils.ExcelExporter;

@Service
@Transactional
public class PersonneServiceImpl implements IPersonneService {

	@Autowired
	private IPersonneRepository personDao;
	
	@Autowired
    private IPersonneRepository personneRepository;

    @Autowired
    private IEnseignantRepository enseignantRepository;
    
    @Autowired
    private CadreAdministrateurRepository adminRepository;
    
    public List<Object[]> getAllPersonnes() {
        try {
            return personDao.findAllPersonneInfo();
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de la récupération de toutes les personnes.", e);
        }
    }
	
    public List<Map<String, Object>> getPersonnesEtEnseignants() {
        List<Personne> personnes = personneRepository.findAll();
        List<Enseignant> enseignants = enseignantRepository.findAll();
        
        List<Map<String, Object>> result = new ArrayList<>();

        for (Personne personne : personnes) {
            for (Enseignant enseignant : enseignants) {
                if (personne.getIdPersonne().equals(enseignant.getIdPersonne())) {
                    Map<String, Object> info = new HashMap<>();
                    info.put("idPersonne", personne.getIdPersonne());
                    info.put("nom", personne.getNom());
                    info.put("prenom", personne.getPrenom());
                    info.put("cin", personne.getCin());
                    info.put("email", personne.getEmail());
                    info.put("specialite", enseignant.getSpecialite());
                    info.put("Departement", enseignant.getDepartement());
                    info.put("Filiere", enseignant.getFiliere());

                    
                    // Récupérer la photo de la personne
                    BufferedImage photo = getPersonnePhoto(personne.getIdPersonne());
                    if (photo != null) {
                        try {
                            // Convertir l'image en base64
                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            ImageIO.write(photo, "png", baos);
                            byte[] photoBytes = baos.toByteArray();
                            String photoBase64 = Base64.getEncoder().encodeToString(photoBytes);
                            // Ajouter la photo en base64 à la Map
                            info.put("photo", "data:image/png;base64," + photoBase64);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    // Ajouter les informations de la personne à la liste de résultats
                    result.add(info);
                }
            }
        }
        return result;
    }
	
	
	public List<Map<String, Object>> getPersonnesEtAdmins() {
        List<Personne> personnes = personneRepository.findAll();
        List<CadreAdministrateur> admins = adminRepository.findAll();
        List<Map<String, Object>> result = new ArrayList<>();

        for (Personne personne : personnes) {
            for (CadreAdministrateur admin : admins) {
                if (personne.getIdPersonne().equals(admin.getIdPersonne())) {
                    Map<String, Object> info = new HashMap<>();
                    info.put("idPersonne", personne.getIdPersonne());
                    info.put("nom", personne.getNom());
                    info.put("prenom", personne.getPrenom());
                    info.put("cin", personne.getCin());
                    info.put("email", personne.getEmail());  
                    info.put("telephone", personne.getTelephone());  
                    info.put("Grade", admin.getGrade());
                    
                    
                    // Ajouter d'autres champs nécessaires
                    result.add(info);
                }
            }
        }

        return result;
    }
    
    
   
    
	public void deletePersonne(Long id) {
        try {
            personDao.deleteById(id);
        } catch (EmptyResultDataAccessException e) {
            throw new EntityNotFoundException("Aucune personne trouvée avec l'ID : " + id, e);
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de la suppression de la personne avec l'ID : " + id, e);
        }
    }

	public Personne getPersonneById(Long id) {
        try {
            return personDao.findById(id).orElseThrow(() -> new EntityNotFoundException("Aucune personne trouvée avec l'ID : " + id));
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de la récupération de la personne avec l'ID : " + id, e);
        }
    }


	public void addPersonne(Personne pPerson) {
        try {
            personDao.save(pPerson);
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de l'ajout de la personne.", e);
        }
    }
	
	public void updatePersonne(Personne pPerson) {
        try {
            personDao.save(pPerson);
        } catch (Exception e) {
            throw new ServiceException("Erreur lors de la mise à jour de la personne.", e);
        }
    }
	public ExcelExporter preparePersonneExport(List<Personne> persons) {
		String[] columnNames = new String[] { "Nom", "Prénom", "CIN", "Email", "Télé" };
		String[][] data = new String[persons.size()][5];

		int i = 0;
		for (Personne u : persons) {
			data[i][0] = u.getNom();
			data[i][1] = u.getPrenom();
			data[i][2] = u.getCin();
			data[i][3] = u.getEmail();
			data[i][4] = u.getTelephone();
			i++;
		}

		return new ExcelExporter(columnNames, data, "persons");

	}

	public Personne getPersonneByCin(String cin) {
	    try {
	        Personne personne = personDao.getPersonneByCin(cin);
	        if (personne == null) {
	            throw new EntityNotFoundException("Aucune personne trouvée avec le CIN : " + cin);
	        }
	        return personne;
	    } catch (Exception e) {
	        throw new ServiceException("Erreur lors de la récupération de la personne avec le CIN : " + cin, e);
	    }
	}

	
	public BufferedImage getPersonnePhoto(Long idPersonne) {
	    // Récupérer la personne par son ID
	    Personne personne = personneRepository.findById(idPersonne)
	            .orElseThrow(() -> new EntityNotFoundException("Personne non trouvée avec l'ID : " + idPersonne));

	    // Récupérer la photo de la personne sous forme de tableau de bytes
	    byte[] photoBytes = personne.getPhoto();

	    if (photoBytes != null) {
	        try {
	            // Lire le tableau de bytes comme une image BufferedImage
	            return ImageIO.read(new ByteArrayInputStream(photoBytes));
	        } catch (IOException e) {
	            // Gérer l'exception si la lecture de l'image échoue
	            e.printStackTrace();
	        }
	    }

	    return null;
	}
}
