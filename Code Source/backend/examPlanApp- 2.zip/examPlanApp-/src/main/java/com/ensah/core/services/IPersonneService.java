package com.ensah.core.services;
import java.awt.image.BufferedImage;


import java.util.List;
import java.util.Map;

import com.ensah.core.bo.Personne;
import com.ensah.core.utils.ExcelExporter;

public interface IPersonneService {

	public void addPersonne(Personne pPerson);

	public void updatePersonne(Personne pPerson);

	List<Object[]> getAllPersonnes();
	
	public List<Map<String, Object>> getPersonnesEtEnseignants();
	public List<Map<String, Object>> getPersonnesEtAdmins();

	
	
	
	public BufferedImage getPersonnePhoto(Long idPersonne);
	
	
	
	
	public void deletePersonne(Long id);

	public Personne getPersonneById(Long id);
	
	public Personne getPersonneByCin(String cin);
	
	public ExcelExporter preparePersonneExport(List<Personne> persons);
	
	

}
