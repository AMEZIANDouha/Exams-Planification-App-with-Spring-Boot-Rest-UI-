package com.ensah.core.services;

import com.ensah.core.bo.Filiere;
import com.ensah.core.dao.IFiliereRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FiliereService {

    private final IFiliereRepository filiereRepository;

    @Autowired
    public FiliereService(IFiliereRepository filiereRepository) {
        this.filiereRepository = filiereRepository;
    }

    public List<Filiere> getAllFilieres() {
        return filiereRepository.findAll();
    }

    // You can add more methods here based on your requirements

}
