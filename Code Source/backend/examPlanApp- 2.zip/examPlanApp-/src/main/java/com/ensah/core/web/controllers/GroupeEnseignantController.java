package com.ensah.core.web.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriUtils;

import com.ensah.core.bo.Departement;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Filiere;
import com.ensah.core.bo.GroupeEnseignant;
import com.ensah.core.dao.IFiliereRepository;
import com.ensah.core.services.GroupeEnseignantService;
import com.ensah.core.services.DepartementService;
import com.ensah.core.services.FiliereService;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/groupes-enseignants")
public class GroupeEnseignantController {

    @Autowired
    private GroupeEnseignantService groupeEnseignantService;
    
    @Autowired
    private DepartementService departementService;
    
    @Autowired
    private FiliereService filiereService; // Inject the FiliereService
    
    @Autowired
    private IFiliereRepository filiereDAO; // Inject the FiliereService


    @RequestMapping(value = "/add")
    @ResponseBody
    public GroupeEnseignant createGroupeEnseignant(@RequestBody GroupeEnseignant groupeEnseignant) {
        return groupeEnseignantService.createGroupeEnseignant(groupeEnseignant);
    }

    @GetMapping("/{id}")
    public GroupeEnseignant getGroupeEnseignantById(@PathVariable Long id) {
        return groupeEnseignantService.getGroupeEnseignantById(id);
    }

    @GetMapping(value="/all")
    public List<GroupeEnseignant> getAllGroupesEnseignants() {
        return groupeEnseignantService.getAllGroupesEnseignants();
    }

    @RequestMapping(value = "/update/{id}" )
    @ResponseBody
    public GroupeEnseignant updateGroupeEnseignant(@PathVariable Long id, @RequestBody GroupeEnseignant groupeEnseignant) {
        groupeEnseignant.setId(id);
        return groupeEnseignantService.updateGroupeEnseignant(groupeEnseignant);
    }
    
    @GetMapping("/get-all-filieres")
    @ResponseBody
    public List<Filiere> getAllFilieres() {
        return filiereDAO.findAll();
    }
    
    @GetMapping("/create-by-filiere")
    @ResponseBody
    public void createGroupesEnseignantsByFiliere() {
        groupeEnseignantService.createGroupesForSameFiliere();
    }

    @RequestMapping(value = "/get-All-Departements")
    @ResponseBody
    public List<Departement> getAllDepartements() {
        return departementService.getAllDepartements(); // Assuming you have a DepartementService to fetch all departments
    }

    @RequestMapping(value ="/create-by-departement")
    @ResponseBody
    public void createGroupesEnseignantsByDepartement(@RequestParam String departmentName) {
        groupeEnseignantService.createGroupesEnseignantsByDepartement(departmentName);
    }
   
    @RequestMapping(value = "/delete/{id}")
    @ResponseBody
    public void deleteGroupeEnseignant(@PathVariable Long id) {
        groupeEnseignantService.deleteGroupeEnseignant(id);
    }
    
    @GetMapping(value = "/create-arbitraire")
    @ResponseBody
    public void createGroupesEnseignantsArbitraire(@RequestParam String nomGroupe, @RequestParam String nomsEnseignants) {
        String decodedNomsEnseignants = UriUtils.decode(nomsEnseignants, "UTF-8");
        List<String> enseignantNames = Arrays.asList(decodedNomsEnseignants.split(","));
        groupeEnseignantService.createGroupesEnseignantsArbitraire(nomGroupe, enseignantNames);
        System.out.println("we're in");
    }
    
    @GetMapping("/{id}/enseignants")
    public List<Enseignant> getEnseignantsByGroupeEnseignantId(@PathVariable Long id) {
        return groupeEnseignantService.getEnseignantsByGroupeEnseignantId(id);
    }
}