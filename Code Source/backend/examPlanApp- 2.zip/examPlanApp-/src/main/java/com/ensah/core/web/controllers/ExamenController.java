package com.ensah.core.web.controllers;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ensah.core.bo.CadreAdministrateur;
import com.ensah.core.bo.ElementPedagogique;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Examen;
import com.ensah.core.bo.Salle;
import com.ensah.core.bo.Semestre;
import com.ensah.core.bo.Session;
import com.ensah.core.bo.Surveillance;
import com.ensah.core.dao.SemestreRepository;
import com.ensah.core.dao.SessionRepository;
import com.ensah.core.dao.TypeExamenRepository;

import com.ensah.core.bo.TypeExamen;
import com.ensah.core.dao.ElementPedagogiqueRepository;
import com.ensah.core.dao.SalleRepository;

import com.ensah.core.services.ExamenService;

@RestController
@RequestMapping("/api/exams")
public class ExamenController {

    @Autowired
    private ExamenService examService;
    
    @Autowired
    private SemestreRepository semestreRepository;

    @Autowired
    private SessionRepository sessionRepository;

    @Autowired
    private TypeExamenRepository typeExamenRepository;
    
    @Autowired
    private ElementPedagogiqueRepository elementpedagogiquerepository;
    
    @Autowired
    private SalleRepository salleRepository;

    @RequestMapping(value = "/create")
    public ResponseEntity<Examen> createExam(
            @RequestParam Date date,
            @RequestParam int dureeReelle,
            @RequestParam Time heureDebut,
            @RequestParam Long idControlleur,
            @RequestParam Long idCordonnateur,
            @RequestParam String elementPedagogique,
            @RequestParam Long semestre,
            @RequestParam Long session,
            @RequestParam Long idSalle, // Changed parameter name to idSalle
            @RequestParam Long typeExamen
    ) {
        Examen exam = new Examen();
        exam.setDate(date);
        exam.setDureeReelle(dureeReelle);
        exam.setHeureDebut(heureDebut);

        
        
        Enseignant cord = new Enseignant();
        cord.setIdPersonne(idCordonnateur);
        exam.setCoordinateur(cord);

        CadreAdministrateur cd = new CadreAdministrateur();
        cd.setIdPersonne(idControlleur);
        exam.setControleursAbsence(cd);

        ElementPedagogique ep = new ElementPedagogique();
        ep.setTitre(elementPedagogique);

        // Save the ElementPedagogique entity before associating it with the Examen
        ElementPedagogique savedElementPedagogique = elementpedagogiquerepository.save(ep);
        exam.setElementPedagogique(savedElementPedagogique);

        // Fetch and set the Semestre entity
        Optional<Semestre> semestreEntity = semestreRepository.findById(semestre);
        if (semestreEntity.isPresent()) {
            exam.setSemestre(semestreEntity.get());
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null); // or handle the case when Semestre is not found
        }

        // Fetch and set the Session entity
        Optional<Session> sessionEntity = sessionRepository.findById(session);
        if (sessionEntity.isPresent()) {
            exam.setSession(sessionEntity.get());
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null); // or handle the case when Session is not found
        }

        // Fetch and set the TypeExamen entity
        Optional<TypeExamen> typeExamenEntity = typeExamenRepository.findById(typeExamen);
        if (typeExamenEntity.isPresent()) {
            exam.setTypeExamen(typeExamenEntity.get());
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null); // or handle the case when TypeExamen is not found
        }

        // Fetch the salle with the given ID from the database
        Optional<Salle> existingSalleOptional = salleRepository.findById(idSalle);
        List<Salle> salles = new ArrayList<>();
        if (existingSalleOptional.isPresent()) {
            // If the salle with the given ID exists, use it
            Salle existingSalle = existingSalleOptional.get();
            salles.add(existingSalle);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null); // or handle the case when Salle is not found
        }

        exam.setSalles(salles);

        Examen newExam = examService.createExamen(exam);
        if (newExam != null) {
            return ResponseEntity.status(HttpStatus.CREATED).body(newExam);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    
    

    @RequestMapping(value = "/Update/{id}")
    @ResponseBody
    public ResponseEntity<Examen> updateExam(
            @RequestParam Long id,
            @RequestParam Date date,
            @RequestParam int dureeReelle,
            @RequestParam Time heureDebut,
            @RequestParam Long idControlleur,
            @RequestParam Long idCordonnateur,
            @RequestParam String elementPedagogique,
            @RequestParam String semestre,
            @RequestParam String session,
            @RequestParam String numeroSalle,
            @RequestParam String typeExamen,
            @RequestParam String rapportTextuelle,
            @RequestParam byte[] epreuvePDF,
            @RequestParam byte[] pvPDF
        ) {
        	
            Examen exam = new Examen();
            exam.setDate(date);
            exam.setDureeReelle(dureeReelle);
            exam.setHeureDebut(heureDebut);
            
            Enseignant cord = new Enseignant();
            cord.setIdPersonne(idCordonnateur);
            exam.setCoordinateur(cord);
            
            CadreAdministrateur cd = new CadreAdministrateur();
            cd.setIdPersonne(idControlleur);
            exam.setControleursAbsence(cd);
            
            ElementPedagogique ep = new ElementPedagogique();
            ep.setTitre(elementPedagogique);
            exam.setElementPedagogique(ep);
            
         // Save the ElementPedagogique entity before associating it with the Examen
            ElementPedagogique savedElementPedagogique = elementpedagogiquerepository.save(ep);
            exam.setElementPedagogique(savedElementPedagogique);
            
            Semestre sm = new Semestre();
            sm.setIntitule(semestre);
            exam.setSemestre(sm);
            
            Session ss = new Session();
            ss.setIntitule(session);
            exam.setSession(ss);
            
            List<Salle> salles = new ArrayList<>(); // Instantiate the list

            // Assuming numeroSalle is the value you want to set for numSalle
            for (Salle salle : salles) {
            	salle.setNumSalle(numeroSalle);
            }

            exam.setSalles(salles);
            
            TypeExamen tp = new TypeExamen();
            tp.setIntitule(typeExamen);
            exam.setTypeExamen(tp);
            
            exam.setRapportTextuel(rapportTextuelle);
            exam.setEpreuvePDF(epreuvePDF);
            exam.setPvPDF(pvPDF);
        Examen updatedExam = examService.updateExamen(id, exam);
        if (updatedExam != null) {
            return ResponseEntity.ok(updatedExam);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @RequestMapping(value = "Delete/{id}")
    @ResponseBody
    public ResponseEntity<Void> deleteExam(@PathVariable Long id) {
        examService.deleteExamen(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Examen> getExamById(@PathVariable Long id) {
        Examen exam = examService.getExamenById(id);
        if (exam != null) {
            return ResponseEntity.ok(exam);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
   
    @GetMapping("/previous-year")
    public ResponseEntity<List<Examen>> getExamsFromPreviousYear() {
        List<Examen> exams = examService.getExamsFromPreviousYear();
        if (!exams.isEmpty()) {
            return ResponseEntity.ok(exams);
        } else {
            return ResponseEntity.noContent().build();
        }
    }
    
    @GetMapping("/all")
    public ResponseEntity<List<Examen>> getAllExams() {
        List<Examen> exams = examService.getAllExams();
        if (!exams.isEmpty()) {
            return ResponseEntity.ok(exams);
        } else {
            return ResponseEntity.noContent().build();
        }
    }
}
