package com.ensah.core.bo;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.awt.image.BufferedImage;
import java.util.*;

import javax.imageio.ImageIO;

import jakarta.persistence.*;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Personne {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPersonne;

    private String nom;
    private String prenom;

    @Column(unique = true)
    private String cin;

    private String email;
    private String telephone;
    private String nomArabe;
    private String prenomArabe;
    @Lob
    private byte[] photo; // Changer le type de photo en byte[]

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, targetEntity = Compte.class)
    private Set<Compte> comptes;

    // Getters et setters

    public Long getIdPersonne() {
        return idPersonne;
    }

    public void setIdPersonne(Long idPersonne) {
        this.idPersonne = idPersonne;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getCin() {
        return cin;
    }

    public void setCin(String cin) {
        this.cin = cin;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getNomArabe() {
        return nomArabe;
    }

    public void setNomArabe(String nomArabe) {
        this.nomArabe = nomArabe;
    }

    public String getPrenomArabe() {
        return prenomArabe;
    }

    public void setPrenomArabe(String prenomArabe) {
        this.prenomArabe = prenomArabe;
    }

    public byte[] getPhoto() {
        return photo;
    }

    public void setPhoto(byte[] photo) {
        this.photo = photo;
    }

    
    public BufferedImage getPhotoAsImage() {
        try {
            if (photo != null) {
                return ImageIO.read(new ByteArrayInputStream(photo));
            } else {
                return null; // Ou vous pouvez retourner une image par défaut si la photo est null
            }
        } catch (IOException e) {
            // Gérer l'exception si la lecture de l'image échoue
            e.printStackTrace();
            return null;
        }
    }
    public Set<Compte> getComptes() {
        return comptes;
    }

    public void setComptes(Set<Compte> comptes) {
        this.comptes = comptes;
    }

    @Override
    public String toString() {
        return "Personne [idPersonne=" + idPersonne + ", nom=" + nom + ", prenom=" + prenom + ", cin=" + cin + ", email="
                + email + ", telephone=" + telephone + ", nomArabe=" + nomArabe + ", prenomArabe=" + prenomArabe
                +  "]";
    }

	public String getLogin() {
		// TODO Auto-generated method stub
		return null;
	}
}
