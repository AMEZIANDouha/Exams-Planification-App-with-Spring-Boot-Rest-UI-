package com.ensah.core.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.stereotype.Service;

import com.ensah.core.bo.Departement;
import com.ensah.core.bo.Enseignant;
import com.ensah.core.bo.Filiere;
import com.ensah.core.bo.GroupeEnseignant;
import com.ensah.core.dao.IDepartementRepository;
import com.ensah.core.dao.IEnseignantRepository;
import com.ensah.core.dao.IFiliereRepository;
import com.ensah.core.dao.IGroupeEnseignantRepository;
import com.ensah.core.services.GroupeEnseignantService;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;

@Service
public class GroupeEnseignantServiceImpl implements GroupeEnseignantService {

	@Autowired
    private IGroupeEnseignantRepository groupeEnseignantDAO;

    @Autowired
    private IDepartementRepository departementDAO;


    @Autowired
    private IEnseignantRepository enseignantDAO;

    private final IFiliereRepository filiereDAO; // Assuming IFiliereRepository is the correct interface

    @Autowired
    public GroupeEnseignantServiceImpl(IFiliereRepository filiereDAO) {
        this.filiereDAO = filiereDAO;
    }
    @Override
    public GroupeEnseignant createGroupeEnseignant(GroupeEnseignant groupeEnseignant) {
        return groupeEnseignantDAO.save(groupeEnseignant);
    }

    @Override
    public GroupeEnseignant updateGroupeEnseignant(GroupeEnseignant groupeEnseignant) {
        return groupeEnseignantDAO.save(groupeEnseignant);
    }

    @Override
    public void deleteGroupeEnseignant(Long id) {
        GroupeEnseignant groupeEnseignant = groupeEnseignantDAO.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Groupe enseignant not found with ID: " + id));
        groupeEnseignantDAO.deleteById(id);
    }

    @Override
    public GroupeEnseignant getGroupeEnseignantById(Long id) {
        return groupeEnseignantDAO.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Groupe enseignant not found with ID: " + id));
    }

    @Override
    public List<GroupeEnseignant> getAllGroupesEnseignants() {
        return groupeEnseignantDAO.findAll();
    }
    
    @Override
    public List<Enseignant> getEnseignantsByGroupeEnseignantId(Long groupeEnseignantId) {
        return enseignantDAO.findByGroupesEnseignantId(groupeEnseignantId);
    }

    @Override
    public void createGroupesEnseignantsArbitraire(String nomGroupe, List<String> nomsEnseignants) {
        List<Enseignant> enseignants = new ArrayList<>();
        for (String nomEnseignant : nomsEnseignants) {
            List<Enseignant> enseignantList = enseignantDAO.findByNom(nomEnseignant);
            if (!enseignantList.isEmpty()) {
                enseignants.addAll(enseignantList);
            } else {
                throw new EntityNotFoundException("Enseignant not found with name: " + nomEnseignant);
            }
        }
        
        GroupeEnseignant groupeEnseignant = new GroupeEnseignant();
        groupeEnseignant.setNom(nomGroupe);
        groupeEnseignant.setEnseignants(enseignants);
        
        // Add the group to each enseignant
        for (Enseignant enseignant : enseignants) {
            enseignant.getGroupesEnseignant().add(groupeEnseignant);
        }

        // Save the group
        groupeEnseignantDAO.save(groupeEnseignant);

        // Save the enseignants (this is necessary to update the join table)
        for (Enseignant enseignant : enseignants) {
            enseignantDAO.save(enseignant);
        }

        System.out.println("Le groupe " + nomGroupe + " a été créé avec succès.");
    }

    @Override
    public void createGroupesEnseignantsByDepartement(String departmentName) {
        Optional<Departement> departementOptional = departementDAO.findByNom(departmentName);
        departementOptional.ifPresent(departement -> {
            GroupeEnseignant groupeEnseignant = new GroupeEnseignant();
            groupeEnseignant.setNom(departmentName);
            List<Enseignant> enseignantsDepartement = departement.getEnseignants();
            
            // Add enseignants to the group and establish bidirectional relationship
            for (Enseignant enseignant : enseignantsDepartement) {
                groupeEnseignant.getEnseignants().add(enseignant);
                enseignant.getGroupesEnseignant().add(groupeEnseignant);
            }

            // Save the group
            groupeEnseignantDAO.save(groupeEnseignant);
        });
    }

    @Override
    public void createGroupesForSameFiliere() {
        // Retrieve all filieres
        List<Filiere> filieres = filiereDAO.findAll();

        // For each filiere, create a group containing its teachers
        for (Filiere filiere : filieres) {
            List<Enseignant> enseignants = enseignantDAO.findByFiliere(filiere);
            if (!enseignants.isEmpty()) {
                GroupeEnseignant groupe = new GroupeEnseignant();
                groupe.setNom(filiere.getNom() + " Group");

                // Add enseignants to the group and establish bidirectional relationship
                for (Enseignant enseignant : enseignants) {
                    groupe.getEnseignants().add(enseignant);
                    enseignant.getGroupesEnseignant().add(groupe);
                }

                // Save the group
                groupeEnseignantDAO.save(groupe);
            }
        }
    }

}
