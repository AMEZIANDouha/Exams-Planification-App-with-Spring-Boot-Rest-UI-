package com.ensah.core.web.controllers;


import org.springframework.http.MediaType;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.imageio.ImageIO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ensah.core.bo.Personne;
import com.ensah.core.services.IPersonneService;
import com.ensah.core.utils.ExcelExporter;

@RestController
@RequestMapping("/api/personnel")
@CrossOrigin(origins = "http://localhost:3000") // Allow requests from your frontend domain
public class PersonneMngController {

    @Autowired
    private IPersonneService personneService;

    @GetMapping("/all")
    public ResponseEntity<List<Object[]>> getAllPersonnes() {
        List<Object[]> personnelList = personneService.getAllPersonnes();
        return new ResponseEntity<>(personnelList, HttpStatus.OK);
    }
    
    @GetMapping("/personnesEtEnseignants")
    public List<Map<String, Object>> getPersonnesEtEnseignants() {
        return personneService.getPersonnesEtEnseignants();
    }
    
    @GetMapping("/personnesEtAdmins")
    public List<Map<String, Object>> getPersonnesEtAdmins() {
        return personneService.getPersonnesEtAdmins();
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Personne> getPersonnelById(@PathVariable("id") Long id) {
        Personne personnel = personneService.getPersonneById(id);
        if (personnel != null) {
            return new ResponseEntity<>(personnel, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
   // @GetMapping("/admins")
    //public ResponseEntity<List<Object[]>> getAllAdmins() {
     //   List<Object[]> adminsList = personneService.findAllAdmins();
      //  return new ResponseEntity<>(adminsList, HttpStatus.OK);
    //}
    
    @PostMapping("/add")
    public ResponseEntity<Personne> addPersonnel(@RequestBody Personne personnel) {
        personneService.addPersonne(personnel);
        return new ResponseEntity<>(personnel, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Personne> updatePersonnel(@PathVariable("id") Long id, @RequestBody Personne personnel) {
        Personne existingPersonnel = personneService.getPersonneById(id);
        if (existingPersonnel != null) {
            personnel.setIdPersonne(id); // Ajouter cette ligne pour s'assurer que l'ID est défini
            personneService.updatePersonne(personnel);
            return new ResponseEntity<>(personnel, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePersonnel(@PathVariable("id") Long id) {
        personneService.deletePersonne(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    @GetMapping("/{id}/photo")
    public ResponseEntity<byte[]> getPersonnePhoto(@PathVariable("id") Long idPersonne) {
        BufferedImage image = personneService.getPersonnePhoto(idPersonne);
        
        if (image != null) {
            try {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                ImageIO.write(image, "png", baos);
                byte[] imageBytes = baos.toByteArray();
                
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.parseMediaType("image/png"));
                
                return ResponseEntity.ok().headers(headers).body(imageBytes);
            } catch (IOException e) {
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        } else {
            return ResponseEntity.notFound().build();
        }

}
    }