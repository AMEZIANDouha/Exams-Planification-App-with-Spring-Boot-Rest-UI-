package com.ensah.core.bo;

public enum Role {
    CadreAdmin,
    Enseignant
}
