package com.ensah.core.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ensah.core.bo.ElementPedagogique;
import com.ensah.core.bo.Enseignant;

@Repository
public interface ElementPedagogiqueRepository extends JpaRepository<ElementPedagogique, Long> {

	List<ElementPedagogique> findByTitre(String titre);

}
