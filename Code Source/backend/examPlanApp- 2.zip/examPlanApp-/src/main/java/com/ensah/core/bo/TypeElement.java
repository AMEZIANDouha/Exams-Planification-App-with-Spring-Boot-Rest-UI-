package com.ensah.core.bo;
import jakarta.persistence.CascadeType;

import jakarta.persistence.Entity;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;


@Entity
public class TypeElement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idType;

    private String titre;

    @OneToMany(mappedBy = "typeElement", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ElementPedagogique> elementsPedagogiques = new HashSet<>();

    // Getters and setters
    public Long getIdType() {
        return idType;
    }

    public void setIdType(Long idType) {
        this.idType = idType;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }
    
    
    public Set<ElementPedagogique> getElementsPedagogiques() {
        return elementsPedagogiques;
    }

    // Setter pour les éléments pédagogiques
    public void setElementsPedagogiques(Set<ElementPedagogique> elementsPedagogiques) {
        this.elementsPedagogiques = elementsPedagogiques;
    }
    
}
