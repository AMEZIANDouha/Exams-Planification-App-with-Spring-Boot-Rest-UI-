package com.ensah.core.services;


import com.ensah.core.bo.CadreAdministrateur;

public interface AdminService {
	
	public CadreAdministrateur createAdmin(CadreAdministrateur admin);
	
	public void deleteAdmin(Long id);
	
	public CadreAdministrateur updateAdmin(Long id, CadreAdministrateur AdminDetails);
	

}