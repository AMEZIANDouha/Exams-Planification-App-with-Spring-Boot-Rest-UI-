package com.ensah.core.services;

import java.util.List;

import com.ensah.core.bo.Salle;

public interface SalleService {
    
    Salle saveSalle(Salle salle);
    
    List<Salle> getAllSalles();
    
    Salle getSalleById(Long id);
    
    void deleteSalle(Long id);
}

