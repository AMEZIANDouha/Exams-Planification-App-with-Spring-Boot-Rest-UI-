package com.ensah.core.web.controllers;

import com.ensah.core.bo.Enseignant;
import com.ensah.core.services.SurveillanceService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/surveillance")
public class SurveillanceController {

    @Autowired
    private SurveillanceService surveillanceService;

    @PostMapping("/assignSurveillants")
    public void assignRandomSurveillants(@RequestParam Long examenId, @RequestParam Long groupeEnseignantId, @RequestParam int nombreSurveillants) {
        surveillanceService.assignRandomSurveillants(examenId, groupeEnseignantId, nombreSurveillants);
    }
    
    @GetMapping("/assignRandomSurveillantsFromEnseignants/{examenId}")
    public List<Enseignant> assignRandomSurveillantsFromEnseignants(@PathVariable Long examenId, @RequestParam int nombreSurveillants) {
        return surveillanceService.assignRandomSurveillantsFromEnseignants(examenId, nombreSurveillants);
    }
}



