package com.ensah.core.bo;


import java.util.ArrayList;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;

@Entity
@PrimaryKeyJoinColumn(name = "idEnseignant")
public class Enseignant extends Personne {

    private String specialite;

    @ManyToOne
    @JoinColumn(name = "idFiliere") 
    private Filiere filiere;
    
    @ManyToOne
    @JoinColumn(name = "idDepartement") 
    private Departement departement;

    // Getters et setters pour departement
    public Departement getDepartement() {
        return departement;
    }

    public void setDepartement(Departement departement) {
        this.departement = departement;
    }

    // Relation one-to-many avec Surveillance en tant que coordonnateur
    @OneToMany(mappedBy = "coordonnateur")
    private List<Surveillance> surveillancesCoordonnees;

    // Relation many-to-many avec Surveillance en tant que surveillant
    @ManyToMany(mappedBy = "surveillants")
    private List<Surveillance> surveillances;
    
    @ManyToMany
    @JoinTable(
        name = "Enseignant_elementsPedagogiques",
        joinColumns = @JoinColumn(name = "Enseignant_idEnseignant"),
        inverseJoinColumns = @JoinColumn(name = "elementsPedagogiques_id")
    )
    private List<ElementPedagogique> elementsPedagogiques = new ArrayList<>();
    
    @ManyToMany
    @JoinTable(
        name = "GroupeEnseignant_enseignants",
        joinColumns = @JoinColumn(name = "enseignants_idEnseignant"),
        inverseJoinColumns = @JoinColumn(name = "groupesEnseignant_id")
    )
    private List<GroupeEnseignant> groupesEnseignant = new ArrayList<>();

    public String getSpecialite() {
        return specialite;
    }

    public void setSpecialite(String specialite) {
        this.specialite = specialite;
    }

    public List<Surveillance> getSurveillancesCoordonnees() {
        return surveillancesCoordonnees;
    }

    public void setSurveillancesCoordonnees(List<Surveillance> surveillancesCoordonnees) {
        this.surveillancesCoordonnees = surveillancesCoordonnees;
    }

    public List<Surveillance> getSurveillances() {
        return surveillances;
    }

    public void setSurveillances(List<Surveillance> surveillances) {
        this.surveillances = surveillances;
    }

    public List<ElementPedagogique> getElementsPedagogiques() {
        return elementsPedagogiques;
    }

    public void setElementsPedagogiques(List<ElementPedagogique> elementsPedagogiques) {
        this.elementsPedagogiques = elementsPedagogiques;
    }
    
 // Getters et Setters pour la relation avec GroupeEnseignant

    public List<GroupeEnseignant> getGroupesEnseignant() {
        return groupesEnseignant;
    }

    public void setGroupesEnseignant(List<GroupeEnseignant> groupesEnseignant) {
        this.groupesEnseignant = groupesEnseignant;
    }
    
    public Filiere getFiliere() {
        return filiere;
    }

    public void setFiliere(Filiere filiere) {
        this.filiere = filiere;
    }

}
