package com.ensah.core.services.impl;

public class UserDao {

}
