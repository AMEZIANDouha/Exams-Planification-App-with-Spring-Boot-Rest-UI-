package bo;

public class UserDao {

}
